# Essentials
Essentials is a mod made with CelLuAPI that makes it cool

## Components

Essentials is made of small parts called components.
There are built-in components, like Toolbar, and custom components made by others.
